﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using System.Net;
using System.Linq;
using System.Text;

namespace CLI
{
    class Resources
    {
        
		
		
		public static string baseUri = "http://localhost:8182/ws";
		
		public static XmlDocument GetScript(string id)
		{
            //TODO: amend this uri
            string uri = null;
			return Rest.GetResourceAsXml(uri);
		}	
		
		public static XmlDocument GetScripts()
		{
            //TODO: amend this uri
            string uri = null;
			return Rest.GetResourceAsXml(uri);
		}
		
		public static XmlDocument GetJob(string id)
		{
            //TODO: amend this uri
            string uri = null;
			return Rest.GetResourceAsXml(uri);
		}
		
		public static XmlDocument GetJobs()
		{
            //TODO: amend this uri
            string uri = null;
			return Rest.GetResourceAsXml(uri);
		}
		
		
		
		
				
		public static XmlDocument PostJob(string request, FileInfo data = null)
		{
            //TODO: amend this uri
            string uri = null;
			if (data == null)
			{
				return Rest.PostResource(uri, request);
			}
			else
			{
                return null;
			}
		}	
		
	}
    
}
