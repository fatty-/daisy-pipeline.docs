Content of this directory:

job-lister: source files of the module
org.daisy.pipeline.modules.job-lister.jar : the packaged Pipeline 2 module