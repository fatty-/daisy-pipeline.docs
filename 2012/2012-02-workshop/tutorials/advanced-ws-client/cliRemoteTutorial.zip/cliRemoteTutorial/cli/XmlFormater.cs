﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.XPath;
namespace CLI
{
    class XmlFormater
    {
        public static string NS="http://www.daisy.org/ns/pipeline/data";
        public static void printScripts(XmlDocument doc) {
            XPathNavigator nav = doc.CreateNavigator();
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("dp", NS);
            // Compile a standard XPath expression
            XPathExpression expr;
            
            expr = nav.Compile("//dp:script");
            expr.SetContext(nsmgr);
            XPathNodeIterator iterator = nav.Select(expr);
            
            try
            {
                while (iterator.MoveNext()) 
                {
                    XPathNavigator node=iterator.Current;    
                    Console.WriteLine("id:\t"+node.GetAttribute("id",""));
                    //"+node.GetAttribute("script","")+":\t ");
                    node.MoveToChild(XPathNodeType.Element);
                    node.MoveToNext(XPathNodeType.Element);
                    Console.WriteLine("desc:\t"+node.Value);
                    Console.WriteLine("----------");
                }
            }
            catch (Exception e) {
                Console.WriteLine(e.Message);
            }
        }
        public static void printScript(XmlDocument doc)
        {
            XPathNavigator nav = doc.CreateNavigator();
            
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("dp", NS);
            // Compile a standard XPath expression
            XPathExpression expr;
            expr = nav.Compile("//dp:input");
            expr.SetContext(nsmgr);
            XPathNodeIterator iterator = nav.Select(expr);
            Console.WriteLine("Inputs:");
            try
            {
                while (iterator.MoveNext())
                {
                    XPathNavigator node = iterator.Current;
                    Console.Write(node.GetAttribute("name", "") + " \t\t");
                    Console.WriteLine(node.GetAttribute("desc", ""));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("");
            Console.WriteLine("");

            expr = nav.Compile("//dp:option");
            expr.SetContext(nsmgr);
            iterator = nav.Select(expr);
            Console.WriteLine("Options:");
            try
            {
                while (iterator.MoveNext())
                {
                    XPathNavigator node = iterator.Current;
                    Console.Write(node.GetAttribute("name", "") + " \t\t");
                    Console.Write(node.GetAttribute("desc", ""));
                    Console.WriteLine("  ( required= "+node.GetAttribute("required", "")+" )");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void printJob(XmlDocument doc)
        {
            XPathNavigator nav = doc.CreateNavigator();
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("dp", NS);
            // Compile a standard XPath expression
            XPathExpression expr;

            expr = nav.Compile("//dp:job");
            expr.SetContext(nsmgr);
            XPathNodeIterator iterator = nav.Select(expr);

            try
            {
                while (iterator.MoveNext())
                {
                    XPathNavigator node = iterator.Current;
                    Console.WriteLine("Job id:\t" + node.GetAttribute("id", ""));
                    //"+node.GetAttribute("script","")+":\t ");
                    Console.WriteLine("desc:\t" + node.GetAttribute("status", ""));
                    Console.WriteLine("----------");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        
    }
}
