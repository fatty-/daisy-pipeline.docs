﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

namespace CLI
{
    class JobRequest
    {
        
        string script;
        Dictionary<string, string> inptus= new Dictionary<string,string>();
        Dictionary<string, string> options = new Dictionary<string, string>();

        public JobRequest(string script, Dictionary<string, string> inptus, Dictionary<string, string> options)
        {
            this.inptus = inptus;
            this.options = options;
            this.script = script;
        }

        

        public string getXml() {
            XmlDocument doc = new XmlDocument();
            XmlNode root = doc.CreateElement("jobRequest", XmlFormater.NS);

            XmlNode script = doc.CreateElement("script", XmlFormater.NS);
            XmlAttribute href=doc.CreateAttribute("href","");
            href.Value=this.script;
            script.Attributes.Append(href);

            doc.AppendChild(root);
            root.AppendChild(script);
            IEnumerator<string> keys=inptus.Keys.GetEnumerator();
            while (keys.MoveNext()) {
                XmlNode input = doc.CreateElement("input", XmlFormater.NS);
                XmlNode file = doc.CreateElement("file", XmlFormater.NS);
                XmlAttribute name = doc.CreateAttribute("name", "");
                name.Value =keys.Current ;
                input.Attributes.Append(name);
                XmlAttribute src = doc.CreateAttribute("src", "");
                src.Value = this.inptus[keys.Current];
                file.Attributes.Append(src);
                input.AppendChild(file);
                root.AppendChild(input);
            }
            keys = options.Keys.GetEnumerator();
            while (keys.MoveNext())
            {
                XmlNode option = doc.CreateElement("option", XmlFormater.NS);
                XmlAttribute name = doc.CreateAttribute("name", "");
                name.Value = keys.Current;
                option.Attributes.Append(name);
                option.InnerText = this.options[keys.Current];
                root.AppendChild(option);
            }

            StringWriter stringWriter = new StringWriter();
            XmlNodeReader xmlReader = new XmlNodeReader(doc);
            XmlTextWriter xmlWriter = new XmlTextWriter(stringWriter);
            xmlWriter.Formatting = Formatting.Indented;
            xmlWriter.Indentation = 1;
            xmlWriter.IndentChar = '\t';
            xmlWriter.WriteNode(xmlReader, true);
            return stringWriter.ToString(); 
            
        }   

        public static string fileToUri(string path){
            return new Uri(path).ToString().Remove(5,2);
        }
    }
}
