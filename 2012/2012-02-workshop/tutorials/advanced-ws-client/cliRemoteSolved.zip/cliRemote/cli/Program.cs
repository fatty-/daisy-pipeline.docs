﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using NDesk.Options;
using System.Xml;

namespace CLI
{
    class Program
    {
        class MainClass
        {
            private static List<string> commands = new List<string> { "scripts", "script", "jobs", "job", "new" };
            public static void Main(string[] args)
            {
                string id = null;
                string inputs=null;
                string options = null;
                bool help = false;
            
                string jobDataFile = null;
                OptionSet opts = new OptionSet() {
				{ "id=", "ID of Job or Script", v => id = v },
                {"inputs=","inputName1,value1;inputName2,value2",v => inputs = v},
                {"options=","optName1,value1;optName2,value2",v => options = v},
				{ "job-data=", "Zip file containing the job data", v => jobDataFile = v},
				{ "help", "Show this message", v => help = v != null },
				
			};
                List<string> cmds = opts.Parse(args);

                if (help || cmds.Count == 0)
                {
                    ShowUsage(opts);
                    return;
                }

                string command = cmds[0];

                if (id == null &&
                    (command == "script" || command == "job" || command == "result" || command == "delete"))
                {
                    Console.WriteLine(String.Format("The command {0} must have an id parameter.", command));
                    ShowUsage(opts);
                    return;
                }

                if (( jobDataFile==null) && command == "new")
                {
                    Console.WriteLine(String.Format("The command {0} must have a job-data parameter.", command));
                    ShowUsage(opts);
                    return;
                }


                if (command == "scripts")
                {
                    GetScripts();
                }
                else if (command == "script")
                {
                    GetScript(id);
                }
                else if (command == "jobs")
                {
                    //GetJobs();
                }
                else if (command == "job")
                {
                    GetJob(id);
                }
                else if (command == "delete")
                {
                    //DeleteJob(id);
                }
                else if (command == "new")
                {
                    Dictionary<string, string> dInputs = parsePairs(inputs);
                    Dictionary<string, string> dOptions = parsePairs(options);
                    if (jobDataFile == null)
                    {

                        PostJob(new JobRequest(id,dInputs,dOptions),null);
                    }
                    else
                    {

                        PostJob(new JobRequest(id, dInputs, dOptions), jobDataFile);
                    }
                }
                else
                {
                    Console.WriteLine("Command not recognized.");
                    ShowUsage(opts);
                    return;
                }
            }
            public static void GetScripts()
            {
                XmlDocument doc = Resources.GetScripts();
                if (doc == null)
                {
                    Console.WriteLine("No data returned.");
                    return;
                }
                //PrettyPrint(doc);
                XmlFormater.printScripts(doc);
            }
            public static void GetScript(string id)
            {
                XmlDocument doc = Resources.GetScript(id);
                if (doc == null)
                {
                    Console.WriteLine("No data returned.");
                    return;
                }
                //PrettyPrint(doc);
                XmlFormater.printScript(doc);
            }
            public static void GetJob(string id)
            {
                XmlDocument doc = Resources.GetJob(id);
                if (doc == null)
                {
                    Console.WriteLine("No data returned.");
                    return;
                }
                //PrettyPrint(doc);
                XmlFormater.printJob(doc);
            }
            public static void PostJob(JobRequest req,string file)
            {
                FileInfo finfo = null;
                if (file != null) {
                    finfo = new FileInfo(file);
                }
                XmlDocument doc = Resources.PostJob(req.getXml(),finfo);
               
                XmlFormater.printJob(doc);
               
            }
            private static void ShowUsage(OptionSet opts)
            {
                Console.WriteLine("Usage: PipelineWSClient [COMMAND] [OPTIONS]+ ");
                Console.WriteLine();
                Console.WriteLine("Commands:");
                foreach (string s in commands)
                {
                    Console.WriteLine(String.Format("\t{0}", s));
                }
                Console.WriteLine();
                Console.WriteLine("Options:");
                opts.WriteOptionDescriptions(Console.Out);

                Console.WriteLine();
                //Console.WriteLine("Examples:");
                //Console.WriteLine("Show all scripts: \n\tPipelineWSClient.exe scripts");
                //Console.WriteLine("Show a specific script: \n\tPipelineWSClient.exe script --id=http://www.daisy.org/pipeline/modules/dtbook-to-zedai/dtbook-to-zedai.xpl");
                //Console.WriteLine("Show a specific job: \n\tPipelineWSClient.exe job --id=873ce8d7-0b92-42f6-a2ed-b5e6a13b8cd7");
                //Console.WriteLine("Create a job: \n\tPipelineWSClient.exe new --job-request=../../../testdata/job1.request.xml");
                //Console.WriteLine("Create a job: \n\tPipelineWSClient.exe new --job-request=../../../testdata/job2.request.xml --job-data=../../../testdata/job2.data.zip");
            }

            public static Dictionary<string,string> parsePairs(string str){
                Dictionary<string, string> pairs = new Dictionary<string, string>();
                if (str != null)
                {
                    string[] sPairs = str.Split(';');
                    for (int i = 0; i < sPairs.Length; i++)
                    {
                        string[] keyVal = sPairs[i].Split(',');
                        pairs.Add(keyVal[0], keyVal[1]);
                    }
                }
                return pairs;

            }



            public static void PrettyPrint(XmlDocument doc)
            {
                using (StringWriter stringWriter = new StringWriter())
                {
                    XmlNodeReader xmlReader = new XmlNodeReader(doc);
                    XmlTextWriter xmlWriter = new XmlTextWriter(stringWriter);
                    xmlWriter.Formatting = Formatting.Indented;
                    xmlWriter.Indentation = 1;
                    xmlWriter.IndentChar = '\t';
                    xmlWriter.WriteNode(xmlReader, true);
                    Console.WriteLine(stringWriter.ToString());
                }
            }

        }
    }
}
